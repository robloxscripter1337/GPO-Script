open launcher.exe
open gpo
enjoy!